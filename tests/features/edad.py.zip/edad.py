"""
>>> edad(0)
'No Existe'

>>> edad(13)
'Eres nino'

>>> edad(18)
'Eres adolecente'

>>> edad(65)
'Eres adulto'

>>> edad(120)
'Eres adulto mayor'

>>> edad(121)
'Eres mumm-ra'
"""

def edad(num1):
        if num1 <= 0:
            return "No Existe"
        if num1 <= 13:
            return "Eres nino"
        if num1 <= 18:
            return "Eres adolecente"
        if num1 <= 65:
            return "Eres adulto"
        if num1 <= 120:
            return "Eres adulto mayor"
        if num1 >= 121:
            return "Eres mumm-ra"

if __name__ == "__main__":
    import doctest
    doctest.testmod()
